package math1;

public class Math02P480 {

	public static void main(String[] args) {
		// min(), max()는 숫자 2개를 입력했을 때 더 큰 쪽이나
		// 혹은 작은쪽을 결과로 출력해줍니다.
		System.out.println(Math.min(1.0, 1.1));
		
		System.out.println(Math.max(31.1, 35.5));

	}

}
